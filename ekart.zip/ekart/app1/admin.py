from django.contrib import admin
from app1.models import Product, Order, Cart


# Register your models here.
#admin.site.register (Product)
#admin.site.register (Order)
#admin.site.register (Cart)

class ProductAdmin(admin.ModelAdmin):
    list_display=["id","name","price","cat","pdetails" ,"is_active"]
    list_filter=["cat","is_active"]

admin.site.register(Product,ProductAdmin)

class OrderAdmin(admin.ModelAdmin):
    list_display=["order_id","user_id","pid","qty","amt"]
    list_filter=["amt"]

admin.site.register(Order,OrderAdmin)

class CartAdmin(admin.ModelAdmin):
    list_display=["user_id","pid","qty"]
    list_filter=["qty"]

admin.site.register(Cart,CartAdmin)
