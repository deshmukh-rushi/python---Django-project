from django.shortcuts import render,HttpResponse,redirect
from django.views import View
from django.contrib.auth.models import User
from django.contrib.auth import login,logout,authenticate
from app1.models import Product, Order, Cart
from django.db.models import Q
from app1 import urls

# Create your views here.

def Register(request):
    context ={}

    if request.method == "GET":
        return render(request,'Register.html')
    else:
        n= request.POST['name']
        p= request.POST['password']
        cp= request.POST['cp']

      
    if n == '' or p == '' or cp == '':
        context['errmsg'] = "fields can not be empty"
        return  render(request,'Register.html',context)
    elif p!= cp:
        context['errmsg'] = "password do not match the confirm password"
        return  render(request,'Register.html',context)
    elif len(p)<8 or len(p)>15:
        context['errmsg'] = "length of the password should be grater than 8 and less than 15"
        return  render(request,'Register.html',context)
    else:
        try:
            u = User.objects.create(username= n)
            u.set_password(p)
            u.save()
            context['success']="Registered successfully !!"
            return render(request,'Register.html',context)
        except Exception as e:
            context['errmsg'] ="already registered please login!!"
            return render(request,'Register.html',context)

def user_login(request):
    if request.method=="GET":
        return render(request,"login.html")     
    else:
        n = request.POST['name']
        p = request.POST['password'] 
        print(n)
        print(p)
        u = authenticate(username=n,password=p) 
        print(u)
        if u is not None:
            login(request,u)
            return render(request,"product details.html")
        else:
            context = {}       
            context['errmsg']= "invalid username or password "
            return render(request,"login.html",context)

def user_logout(request):
    logout(request)
    return render("index.html")

def home(request):
    p=Product.objects.all()  # equivalent to select all query in sql 
    context={}
    context["product"]=p
    return render(request,"index.html",context)


def about(request):
    return render(request,"About us.html")

def contact(request):
    return render(request,"Contact us.html")

def products(request,pid):
    p=Product.objects.filter(id=pid)  # equivalent to select all query in sql 
    #print(p)
    context={}
    context["product"]=p
    return render(request,"product details.html",context)

def sort(request,sv):
    if sv == '1':
        p = Product.objects.order_by('-price').filter(is_active=True)
    else:
        p =  Product.objects.order_by('price').filter(is_active=True)
    context ={}
    context['product'] = p
    return render(request,"index.html",context)

def cart(request,pid):
    if request.user.is_authenticated:
        u= User.objects.filter(id= request.user.id)
        p= Product.objects.filter(id=pid)
        q1 =Q(user_id = u[0])
        q2 =Q(pid = p[0])
        c= Cart.objects.filter(q1 & q2)
        n = len(c)

        context={}
        context['data'] = p
        if n ==1:
            context['msg'] = "product already exist in cart"
        else:
            c= Cart.objects.create(user_id= u[0],pid=p[0])
            c.save()
            context['msg']="product successfully added to cart" 
        return render(request,"product details.html",context)

def pricefilter(request):
    min= request.GET["min"]
    max= request.GET["max"]
    print(min)
    print(max)
    q1=Q(price__gte=min)
    q2=Q(price__lte=max)
    p=Product.objects.filter(q1 & q2) # this stmt is equivalent to sql query 
    context={}
    context["product"]=p
    return render(request,"index.html",context)
    
def viewcart(request):
    c=Cart.objects.filter(user_id=request.user.id)
    print(c[0])
    print(c[0].user_id)
    print(c[0].user_id.is_staff)
    print(c[0].pid.name)
    #return HttpResponse("data fetched !")
    context={}
    context["cart"]=c
    return render(request,"cart.html",context)
    