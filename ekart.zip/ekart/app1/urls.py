from django.contrib import admin
from django.urls import path,include
from app1 import views
from django.conf import settings
from django.conf.urls.static import static 



urlpatterns = [
    path('admin/', admin.site.urls),
    path('register',views.Register),
    path('login',views.user_login),
    path('logout', views.user_logout),
    path('product<pid>',views.products),
    path('home',views.home),
    path('cart<pid>',views.cart),
    path('about',views.about),
    path('contact',views.contact),
    path('pricefilter',views.pricefilter),
    path('sort<sv>' ,views.sort),
    path('viewcart',views.viewcart),

    
]

if settings.DEBUG:
    urlpatterns+=static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)