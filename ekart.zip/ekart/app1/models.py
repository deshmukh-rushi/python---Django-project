from django.db import models

# Create your models here.

class Customer(models.Model):
    name = models.CharField(max_length = 100)
    email = models.EmailField()
    mobile = models.BigIntegerField()
    password = models.CharField(max_length=100)

class Product(models.Model):
    CAT = (('Mobile',1),('clothes',2),('shoes',3))
    name= models.CharField(max_length=50, verbose_name="product name")
    price = models.IntegerField()
    cat = models.CharField(max_length=100 , verbose_name="category", choices=CAT)
    pdetails = models.CharField(max_length=100,verbose_name = "product details")
    is_active = models.BooleanField(default= True)
    pimage = models.ImageField(upload_to="image")

    """def __str__(self):
        return self.name """
       



class Cart(models.Model):
    user_id = models.ForeignKey('auth.user',on_delete = models.CASCADE,db_column ='user_id')
    pid=models.ForeignKey('Product',on_delete=models.CASCADE,db_column='pid')
    qty=models.IntegerField(default =1)

class Order(models.Model):
    order_id = models.CharField(max_length=50)
    user_id = models.ForeignKey('auth.user',on_delete =models.CASCADE,db_column='user_id')
    pid= models.ForeignKey('Product',on_delete =models.CASCADE,db_column='pid')
    qty=models.IntegerField(default =1)
    amt= models.FloatField() 